
/**
 * You don't have to modify this source file, but can if you want.
 * This will not be used for grading, so you can use it to debug your
 * vector class.
 * This is the program that runs with "make run"
 */

///	Your welcome
#include <iostream>
#include "MyVector.hpp"

using std::cout, std::endl;

int main()
{
    cout << "Hello! Maybe use this source file for debugging?" << endl;
    CPSC131::MyVector::MyVector<int> myVector;

    myVector.push_back(10);
    myVector.push_back(20);
    myVector.push_back(30);
    myVector.push_back(40);
    myVector.push_back(50);
    myVector.push_back(60);
    myVector.push_back(70);
    myVector.push_back(80);

    cout << "Vector elements: ";
    for (size_t i = 0; i < myVector.size(); ++i) {
        cout << myVector[i] << " ";
    }
    cout << endl;

    /// Insert an element at index 2
    myVector.insert(2, 99);

    cout << "Vector elements after insert: ";
    for (size_t i = 0; i < myVector.size(); ++i) {
        cout << myVector[i] << " ";
    }
    cout << endl;

    /// Erase an element at index 4
    myVector.erase(4);

    cout << "Vector elements after erase: ";
    for (size_t i = 0; i < myVector.size(); ++i) {
        cout << myVector[i] << " ";
    }
    cout << endl;

    cout << "Vector size: " << myVector.size() << endl;
    cout << "Vector capacity: " << myVector.capacity() << endl;
    
    cout << "I tried" << endl;

    return 0;
}
