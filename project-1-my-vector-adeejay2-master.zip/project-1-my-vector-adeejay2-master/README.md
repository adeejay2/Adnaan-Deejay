# Project - MyVector
My submission for CPSC 131, Section 06, Vector Project 1
# My Information
* Name: Adnaan Deejay
* CWID: 884614959
* Email: adeejay2@csu.fullerton.edu
