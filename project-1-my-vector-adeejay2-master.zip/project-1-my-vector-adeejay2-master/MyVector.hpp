
/******************* 
name: Adnaan Deejay
CWID: 884614959
Email: adeejay2@csu.fullerton.edu 
******************/


/// Your welcome
#include <assert.h>
#include <iostream>
#include <string>

namespace CPSC131::MyVector
{
	
	template <typename T>
	class MyVector
	{
		public:
			
			/*******************
			 * Static constants
			 ******************/
			
			/// Default capacity
			static constexpr size_t DEFAULT_CAPACITY = 64;
			
			/// Minimum capacity
			static constexpr size_t MINIMUM_CAPACITY = 8;
			
			/*****************************
			 * Constructors / Destructors
			 ****************************/
			
			/// Normal constructor
			MyVector(size_t capacity = MyVector::DEFAULT_CAPACITY) 
            : size_(0), capacity_(std::max(capacity, MINIMUM_CAPACITY)) {
            elements_ = new T[capacity_];
			}

			/// Copy constructor
			MyVector(const MyVector& other)
				: size_(other.size_), capacity_(other.capacity_) {
			elements_ = new T[capacity_];
			for (size_t i = 0; i < size_; i++) {
				elements_[i] = other.elements_[i];
				}
			}

			
			/**
			 * Destructor
			 * Cleanup here.
			 */
			~MyVector() {
			clear();
			}
				
			/************
			 * Operators
			 ************/
			
			///	Assignment operator
			
			MyVector& operator=(const MyVector& rhs) {
					if (this != &rhs) {
						clear();

						size_ = rhs.size_;
						capacity_ = rhs.capacity_;
						elements_ = new T[capacity_];
						for (size_t i = 0; i < size_; i++) {
							elements_[i] = rhs.elements_[i];
						}
					}
					return *this;
				}


			/// Operator overload to at()
			T& operator[](size_t index) const {
				if (index >= size_) {
					throw std::out_of_range("Index is out of range");
				}
				return elements_[index];
			}

			
			/************
			 * Accessors
			 ************/
			
			/// Return the number of valid elements in our data
			size_t size() const
			{
				return size_;
			}
			
			/// Return the capacity of our internal array
			size_t capacity() const
			{
				return capacity_;
			}
			
			/**
			 * Check whether our vector is empty
			 * Return true if we have zero elements in our array (regardless of capacity)
			 * Otherwise, return false
			 */
			bool empty() const
			{	
				return size_ == 0;
			}
			
			T& at(size_t index) const{
				if (index >= size_) {
					throw std::out_of_range("Index is out of range");
				}
				return elements_[index];
			}
			
			/***********
			 * Mutators
			 ***********/
			
			/**
			 * Reserve capacity in advance, if our capacity isn't currently large enough.
			 * Useful if we know we're about to add a large number of elements,
			 *   and we'd like to avoid the overhead of many internal changes to capacity.
			 */
			 /// above or equal to minimum, exception if req capacity cant support size
			void reserve(size_t new_capacity) {
				if (new_capacity < capacity_) {
					return;
				}
				
				if (new_capacity < MINIMUM_CAPACITY) {
				new_capacity = MINIMUM_CAPACITY;
				}
				
				if ( new_capacity < size_ ) {
				throw std::out_of_range("Reserve, requested capacity that is too small");
				}

					T* new_elements = new T[new_capacity];
					for (size_t i = 0; i < size_; i++) {
						new_elements[i] = elements_[i];
					}
					delete[] elements_;
					elements_ = new_elements;
					capacity_ = new_capacity;
				} 
			/**
			 * Set an element at an index.
			 * Throws range error if outside the size boundary.
			 * Returns a reference to the newly set element (not the original)
			 */
			T& set(size_t index, const T& element) {
				if (index >= size_) {
					throw std::out_of_range("Index is out of range");
				}

				/// Call destructor of the existing element
				elements_[index].~T();
				
				new (&elements_[index]) T(element);

				return elements_[index];
			}


			
			/**
			 * Add an element onto the end of our vector.
			 * Returns a reference to the newly inserted element.
			 */
			T& push_back(const T& element) {
				if (size_ == capacity_) {
					reserve(2 * capacity_);
				}
				elements_[size_] = element;
				size_++;
				return elements_[size_ - 1];
			}

			/**
			 * Remove the last element in our vector.
			 * Should throw std::range_error if the vector is already empty.
			 * Returns a copy of the element removed.
			 */
			T pop_back() {
				if (size_ == 0) {
					throw std::out_of_range("Vector is empty");
				}

				T popped_element = elements_[size_ - 1];
				size_--;

				/// Check if the new size is less than one-third of current capacity
				if (size_ < capacity_ / 3 && capacity_ > MINIMUM_CAPACITY) {
					size_t new_capacity = std::max(capacity_ / 2, MINIMUM_CAPACITY);
					changeCapacity(new_capacity);
				}

				if (size_ == 0) {
					changeCapacity(MINIMUM_CAPACITY);
				}

				return popped_element;
			}

			/**
			 * Insert an element at some index in our vector
			 * 
			 * Example:
			 * 	 Insert a 9 at index 2
			 *   Contents before: [6, 2, 7, 4, 3]
			 *   Contents after:  [6, 2, 9, 7, 4, 3]
			 * 
			 * Returns a reference to the newly added element (not the original).
			 */
			T& insert(size_t index, const T& element) {
				if (index > size_) {
					throw std::out_of_range("Index is out of range");
				}

				if (size_ == capacity_) {
					reserve(2 * capacity_);
				}
				
				for (size_t i = size_; i > index; --i) {
					elements_[i] = elements_[i - 1];
				}

				elements_[index] = element;
				++size_;
				return elements_[index];
			}

			/**
			 * Erase one element in our vector at the specified index
			 * 
			 * Throws std::range_error if the index is out of bounds.
			 * 
			 * Example:
			 *   Erase index 2
			 *   Contents before: [8, 4, 3, 9, 1]
			 *   Contents after:  [8, 4, 9, 1]
			 * 
			 * Returns a copy of the erased element.
			 * Hint: call DTOR on original after making the copy.
			 */
			T erase(size_t index) {
				if (index >= size_) {
					throw std::out_of_range("Index is out of range");
				}

				T erased_element = elements_[index];

				for (size_t i = index; i < size_ - 1; i++) {
					elements_[i] = elements_[i + 1];
				}

				--size_;
				
				if (size_ < capacity_ / 3 && capacity_ > MINIMUM_CAPACITY) {
					size_t new_capacity = std::max(capacity_ / 2, MINIMUM_CAPACITY);
					changeCapacity(new_capacity);
				}

				return erased_element;
			}

			/**
			 * Removes all elements (i.e., size=0 and DTORs called)
			 * 
			 * Should also reset capacity, if needed
			*/
			void clear() {
				delete[] elements_;
				elements_ = new T[DEFAULT_CAPACITY];
				capacity_ = DEFAULT_CAPACITY;
				size_ = 0;
			}


		/**
		 * Begin private members and methods.
		 * You may add your own private helpers here, if you wish.
		*/
		private:
			
			/// Number of valid elements currently in our vector
			size_t size_ = 0;
			
			/// Capacity of our vector; The actual size of our internal array
			size_t capacity_ = 0;
			
			/**
			 * Our internal array of elements of type T.
			 * Starts off as a null pointer.
			 */
			T* elements_ = nullptr;
			
			/**
			 * Helper function that is called whenever we need to change the capacity of our vector.
			 * Should throw std::range_error when asked to change to a capacity that cannot hold our existing elements.
			 */
			void changeCapacity(size_t new_capacity) {
			///if new capacity being sent is larger than size
			///copy array into a new array and delete the old, set pointers
			 if (new_capacity < size_) {
				throw std::range_error("New capacity cannot be less than the current size");
			}

			T* new_elements = new T[new_capacity];

			/// Copy elements to the new array
			for (size_t i = 0; i < size_; i++) {
				new_elements[i] = elements_[i];
			}

			/// Delete the old array
			delete[] elements_;

			/// Set pointers to the new array and update capacity
			elements_ = new_elements;
			capacity_ = new_capacity;

				}
		};
}


